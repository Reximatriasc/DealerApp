package com.example.dealerapp.ui

class LoginFragment {
}