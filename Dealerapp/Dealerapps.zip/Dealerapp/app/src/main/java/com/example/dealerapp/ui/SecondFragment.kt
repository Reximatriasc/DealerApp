package com.example.dealerapp.ui

import android.content.Context
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import com.example.dealerapp.application.DealerApplication
import com.example.dealerapp.databinding.FragmentSecondBinding
import com.example.dealerapp.model.Dealer
import com.google.android.gms.location.LocationServices
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.R
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.BitmapDescriptorFactory
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.Marker
import com.google.android.gms.maps.model.MarkerOptions

/**
 * A simple [Fragment] subclass as the second destination in the navigation.
 */
class SecondFragment : Fragment(), OnMapReadyCallback, GoogleMap.OnMarkerDragListener {

    private var _binding: FragmentSecondBinding? = null
    private val binding get() = _binding!!
    private lateinit var applicationContext: Context
    private val dealerViewModel: DealerappViewModel by viewModels {
        DealerViewModelFactory((applicationContext as DealerApplication).repository)
    }
    private val args : SecondFragmentArgs by navArgs()
    private var dealer: Dealer? = null
    private lateinit var mMap: GoogleMap
    private var currentLatLng: LatLng? = null

    override fun onAttach(context: Context) {
        super.onAttach(context)
        applicationContext = requireContext().applicationContext
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        _binding = FragmentSecondBinding.inflate(inflater, container, false)
        return binding.root

    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        dealer = args.dealer
        if (dealer!= null){
            binding.deleteButton.visibility = View.VISIBLE
            binding.saveButton.text = "Update"
            binding.NamaDealerEditText.setText(dealer?.Nama)
            binding.AlamatEditText.setText(dealer?.Alamat)
            binding.TelpEditText.setText(dealer?.Telp)
        }

        // binding google map
        val mapFragment = childFragmentManager
            .findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)

        val Nama= binding.NamaDealerEditText.text
        val Alamat= binding.AlamatEditText.text
        val Telp = binding.TelpEditText.text
        binding.saveButton.setOnClickListener {
            if (Nama.isEmpty()) {
                Toast.makeText(context, "Nama tidak boleh kosong", Toast.LENGTH_SHORT).show()
            } else if (Alamat.isEmpty()) {
                Toast.makeText(context, "Alamat tidak boleh kosong", Toast.LENGTH_SHORT).show()
            } else if (Telp.isEmpty()) {
                Toast.makeText(context, "Telp tidak boleh kosong", Toast.LENGTH_SHORT).show()
            } else {
                if (dealer == null) {
                    val dealer =
                        Dealer(0, Nama.toString(), Alamat.toString(), Telp.toString())
                   dealerViewModel.insert(dealer)
                } else {
                    val dealer = Dealer(
                        dealer?.id!!,
                        Nama .toString(),
                        Alamat.toString(),
                        Telp.toString()
                    )
                    dealerViewModel.update(dealer)
                }
                findNavController().popBackStack() // untuk dismis halaman ini
            }
        }

        binding.deleteButton.setOnClickListener {
            dealer?.let { dealerViewModel.delete(it) }
            findNavController().popBackStack()
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    override fun onMapReady(googleMap: GoogleMap) {
        mMap = googleMap

        val uiSettings = mMap.uiSettings
        uiSettings.isZoomControlsEnabled = true
        mMap.setOnMarkerDragListener(this)
    }

    override fun onMarkerDrag(p0: Marker) {}

    override fun onMarkerDragEnd(marker: Marker) {
        val newPosition = marker.position
        currentLatLng = LatLng(newPosition.latitude, newPosition.longitude)
        Toast.makeText(context,currentLatLng.toString(),Toast.LENGTH_SHORT).show()
    }

    override fun onMarkerDragStart(p0: Marker) {
    }

    private fun checkPermission(){
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(applicationContext)
        if (ContextCompat.checkSelfPermission(
                applicationContext,
                android.Manifest.permission.ACCESS_FINE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED
        ){
            getCurrentLocation()
        }else{
            Toast.makeText(applicationContext, "Akses Lokasi Ditolal", Toast.LENGTH_SHORT).show()
        }
    }

    private fun getCurrentLocation(){
        if (ContextCompat.checkSelfPermission(
                applicationContext,
                android.Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
        ){
            return
        }

        fusedLocationClient.lastLocation
            .addOnSuccessListener { location ->
                if (location != null){
                    var latLang = LatLng(location.latitude, location.longitude)
                    var currentLatLang = latLang
                    var title = "Marker"

                    if (dealer != null){
                        title = dealer?.name.toString()
                        val newCurrentLocation = LatLng(dealer?.latitude!!, dealer?.longtitude!!)
                        latLang = newCurrentLocation
                    }
                    val markerOptions = MarkerOptions()
                        .position(latLang)
                        .title(title)
                        .draggable(true)
                        .icon(BitmapDescriptorFactory.fromResource(R.drawable.iconn))
                    mMap.addMarker (markerOptions)
                    mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(latLang, 15f))
                }
            }
    }
}